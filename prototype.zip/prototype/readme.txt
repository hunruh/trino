Use the arrow keys to move around.
Press the 1-2-3 buttons to transform into different forms (denoted now by the different colors).